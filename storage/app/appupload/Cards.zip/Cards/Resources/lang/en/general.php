<?php

return [

    'name'              => 'Cards',
    'description'       => 'This is my awesome module',

];