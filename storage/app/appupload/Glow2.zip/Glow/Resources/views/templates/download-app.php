 
 <!-- download-app-->
 <section class='section section-download-app'>
     <div class='packer'>
         <div class='package'>
             <div class='content'>
                 <div class='rounded-box'>
                     <div class='info'>
                         <div class='heading'>
                             <h3>Download the App</h3>
                             <p>Order now using your phone (iOS or Android) in three simple steps: Add, Cart, Send.</p>
                         </div>
                         <div class='stores'>
                             <div class='item'>
                                 <a href='javascript:;'>
                                     <img loading="lazy" src='https://via.placeholder.com/318x96' />

                                 </a>
                             </div>
                             <div class='item'>
                                 <a href='javascript:;'>
                                     <img loading="lazy" src='https://via.placeholder.com/318x96' />
                                 </a>
                             </div>
                             <div class='item'>
                                 <a href='javascript:;'>
                                     <img loading="lazy" src='https://via.placeholder.com/318x96' />
                                 </a>
                             </div>
                         </div>
                     </div>
                     <picture data-background=true>
                         <source srcset="https://placekitten.com/800/600" media="(min-width: 1201px)" />
                         <source srcset="https://placekitten.com/1200/400" media="(min-width: 569px)" />
                         <img loading="lazy" src='https://placekitten.com/400/400' />
                     </picture>
                 </div>
             </div>
         </div>
     </div>
 </section>