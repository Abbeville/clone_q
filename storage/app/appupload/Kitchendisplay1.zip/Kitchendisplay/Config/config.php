<?php

return [
    'name' => 'Kitchendisplay'
];
