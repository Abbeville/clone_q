<?php

return [

    'name'              => 'Mercadopago',
    'description'       => 'This is my awesome module',

];