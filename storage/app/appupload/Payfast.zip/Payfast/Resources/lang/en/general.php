<?php

return [

    'name'              => 'Payfast',
    'description'       => 'This is my awesome module',

];