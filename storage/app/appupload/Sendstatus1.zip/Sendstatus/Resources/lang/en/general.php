<?php

return [

    'name'              => 'Sendstatus',
    'description'       => 'This is my awesome module',

];