<?php

return [

    'name'              => 'Tinypng',
    'description'       => 'This is my awesome module',

];