<?php

return array (
  'customer_phone_number' => 'Customer phone number',
  'client_phone'=>'Customer phone number',
  'client_name'=>"Client name"
);
